﻿namespace APIConnectify.NET.Models
{
    public class Friends
    {
        public int Id { get; set; }
        public Users FriendsName { get; set; }
         
        public Friends(int id, Users friendsName)
        {
            Id = id;
            FriendsName = friendsName;
        }
        public Friends()
        {

        }
    }
}
