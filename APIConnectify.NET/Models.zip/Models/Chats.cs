﻿namespace APIConnectify.NET.Models
{
    public class Chats
    {
        public int Id { get; set; }



    }
}
